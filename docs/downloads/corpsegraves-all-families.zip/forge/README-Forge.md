# Corpse Graves — Forge 1.20.1

- Mod: `corpsegraves-1.1.0+1.20.1-forge.jar`
- Requires **Minecraft 1.20.1**, **Forge 47.x** (built and tested against 47.4.28) and **Java 17**.
- No other dependencies.

## Features

- On death the player's whole inventory and a configurable share of XP are stored in a corpse grave instead of dropping on the ground.
- The corpse renders the fallen player's real skin in a lying pose, using a custom `CorpseEntity` + `PlayerModel` renderer.
- Floating hologram with the player name, despawn countdown and protection countdown/status.
- Owner protection with a configurable unlock timer; owners and operators (configurable) always have access.
- Right-click to open the grave GUI (Take All / Restore) on a client with the mod.
- Shift + right-click for instant quick restore into the original slots.
- Floats a wide invisible hitbox so the grave is easy to click; right-clicking it with a vanilla client takes all loot (server fallback).
- Smart despawn: timer pauses while the owner is offline; the grave persists across restarts and only disappears when loot/despawn is handled.
- Void rescue, soul particles, configurable pose/offsets, hologram colors/scale/background, XP percentage, max graves per player, and more.
- JSON config at `config/corpsegraves.json`; `/corpsegraves reload` reloads it live.

## Tested (production dedicated server)

Dedicated Forge 1.20.1-47.4.28 server, built jar in `mods/`:

- Server reaches `Done` with the mod loaded; config generated.
- Real death via the Forge `LivingDeathEvent`: items and XP moved into the grave, vanilla drops suppressed, inventory/XP cleared.
- Hologram + Interaction hitbox spawn correctly through the access transformer (no AT errors).
- Vanilla-client connection accepted; right-click on the hitbox takes all items and recovers 50% XP.
- Shift + right-click (interaction packet with sneak flag) hits the quick-restore path and merges stacks into original slots.
- Grave and visuals are removed after looting; no exceptions in the server log.
- `/corpsegraves reload`, `locate` and `help` work.
- Survival of multiple restarts with stored grave entities (persistence).

## Client test (Forge 1.20.1 dev client, same code path)

- Corpse renderer: the fallen player is drawn as a complete lying player model on the ground with a soft shadow.
- Skin lookup: traced at runtime to the owner's live player (`Tester` → `textures/entity/player/wide/noor.png`, the default skin for that skinless test bot). With a real player skin/online profile the same `getSkinTextureLocation()` path returns the custom skin.
- Hologram: three readable lines (name / despawn / protection) above the grave, correct colors, transparent background.
- GUI: right-click opens the custom dark screen with Take All/Restore; **Take All worked** (all stacks moved to the player and 698 XP recovered), the grave and its hologram/hitbox were removed, no exceptions.
- The title and despawn timer are stacked on two header lines so long player names no longer collide.

## Client notes

- Install on both client and server for the corpse model/skin and the GUI.
- A vanilla client can join a server running this mod: it sees the hologram/hitbox and can quick-loot, but not the corpse body or GUI.
- The custom renderer pose is configurable (`corpse.yOffset`, `corpse.yawOffset`); the default matches the Fabric legacy ports.

## Commands

- `/corpsegraves locate` — nearest grave of the player.
- `/corpsegraves reload` — reload `config/corpsegraves.json` (permission 2).
- `/corpsegraves unlock <player>` / `remove <player>` — admin (permission 2).

## Install

1. Install Forge 1.20.1 (47.x) for the client and/or the dedicated server.
2. Drop `corpsegraves-1.1.0+1.20.1-forge.jar` into `mods/` on every side where you want the mod.
3. Optionally copy `corpsegraves.sample.json` to `config/corpsegraves.json` before first start (the mod creates defaults otherwise).
4. Remove any older Corpse Graves jar for a different loader/version.
