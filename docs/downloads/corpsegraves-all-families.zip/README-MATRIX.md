# Corpse Graves 1.1.0 — full loader/version matrix

23 mod jars: 9 Fabric, 8 Forge, 6 NeoForge. "Boot OK" means a dedicated server loaded the jar and reached `Done`; "client test" means a real game client joined and used the grave. Every jar is listed in `SHA256SUMS.txt`.

## Fabric — 26.x (Java 25)

| MC | Jar | Fabric API | Test |
|---|---|---|---|
| 26.1 | `26.x/corpsegraves-1.1.0+26.1.jar` | 0.155.3+26.1.2 | Boot OK |
| 26.1.1 | `26.x/corpsegraves-1.1.0+26.1.1.jar` | 0.155.3+26.1.2 | Boot OK |
| 26.1.2 | `26.x/corpsegraves-1.1.0+26.1.2.jar` | 0.155.3+26.1.2 | Boot OK |
| 26.2 | `26.x/corpsegraves-1.1.0+26.2.jar` | 0.161.0+26.2 | Boot OK |
| 26.3 | `26.x/corpsegraves-1.1.0+26.3.jar` | 0.165.0+26.3 | Boot OK + full client gameplay |
| 26.4 snapshot 6 | `26.x/corpsegraves-1.1.0+26.4.jar` | 0.165.1+26.4 | Boot OK |

Loader floor is 0.19.3; the release 26.3 jar booted dedicated servers on **Loader 0.19.5 and 0.20.1**. The 26.3 build uses the vanilla Mannequin architecture and had the deepest gameplay pass (death, live skin, both hologram timers, GUI buttons, Take All, 50% XP, Shift restore, restart persistence).

## Fabric — legacy (Java 21 / 17)

| MC | Jar | Fabric API | Test |
|---|---|---|---|
| 1.21.1 | `fabric-legacy/corpsegraves-1.1.0+1.21.1.jar` | 0.116.17+1.21.1 | Boot OK + client GUI |
| 1.21 | `fabric-legacy/corpsegraves-1.1.0+1.21.jar` | 0.102.0+1.21 | Boot OK + hitbox loot |
| 1.20.1 | `fabric-legacy/corpsegraves-1.1.0+1.20.1.jar` | 0.92.12+1.20.1 | Boot OK + client GUI |

These use the custom CorpseEntity + PlayerModel renderer with the live skin, TextDisplay hologram, invisible Interaction hitbox, the same timers/GUI/config, and survive restarts.

## Forge (Java 25 for 26.x, 21 for 1.21.x, 17 for 1.20.1)

| MC | Forge | Jar | Test |
|---|---|---|---|
| 26.3 | 66.1.2 | `forge/corpsegraves-1.1.0+26.3-forge.jar` | Boot OK + real client GUI/Take All |
| 26.2 | 65.1.5 | `forge/corpsegraves-1.1.0+26.2-forge.jar` | Boot OK |
| 26.1.2 | 64.1.5 | `forge/corpsegraves-1.1.0+26.1.2-forge.jar` | Boot OK |
| 26.1.1 | 63.0.2 | `forge/corpsegraves-1.1.0+26.1.1-forge.jar` | Boot OK |
| 26.1 | 62.0.9 | `forge/corpsegraves-1.1.0+26.1-forge.jar` | Boot OK |
| 1.21.1 | 52.1.20 | `forge/corpsegraves-1.1.0+1.21.1-forge.jar` | Boot OK + vanilla-bot quick loot |
| 1.21 | 51.0.33 | `forge/corpsegraves-1.1.0+1.21-forge.jar` | Boot OK + vanilla-bot quick loot |
| 1.20.1 | 47.x (tested 47.4.28) | `forge/corpsegraves-1.1.0+1.20.1-forge.jar` | Boot OK + real client + two-player protection |

The Forge channel is optional, so vanilla clients can join and use the server-side quick-loot fallback. A modded Forge client gets the corpse body and the Take All/Restore GUI.

## NeoForge

| MC | NeoForge | Jar | Test |
|---|---|---|---|
| 26.3 | 26.3.0.100 | `neoforge/corpsegraves-1.1.0+26.3-neoforge.jar` | Boot OK + real client GUI/Take All |
| 26.2 | 26.2.0.93 | `neoforge/corpsegraves-1.1.0+26.2-neoforge.jar` | Boot OK |
| 26.1.2 | 26.1.2.125 | `neoforge/corpsegraves-1.1.0+26.1.2-neoforge.jar` | Boot OK |
| 1.21.1 | 21.1.176 | `neoforge/corpsegraves-1.1.0+1.21.1-neoforge.jar` | Boot OK + real client GUI/Take All |
| 1.21 | 21.0.167 | `neoforge/corpsegraves-1.1.0+1.21-neoforge.jar` | Boot OK |
| 1.20.1 | 47.1.106 (legacy fork) | `neoforge/corpsegraves-1.1.0+1.20.1-neoforge.jar` | Boot OK + vanilla-client quick loot (3 stacks + 698 XP) |

NeoForge 1.20.1 is a legacy binary-compatible fork of Forge 47.1.x, so the jar is byte-identical to the Forge 1.20.1 build. Verified live: the grave spawned, a vanilla client clicked the Interaction hitbox, the server-side fallback returned 64 diamonds / 32 iron / 16 golden apples plus 698 XP, and the grave/hologram/hitbox were removed.

NeoForge clients must have the mod; its network negotiation rejects vanilla clients, so the hologram/hitbox fallback is not reachable from unmodded clients.

## Proven gaps (upstream, not unfinished ports)

- **Minecraft 26.4:** no Forge and no NeoForge release exists in their Maven metadata, so only Fabric 26.4 is provided.
- **NeoForge 26.1 / 26.1.1:** never published by NeoForge (the 26.1.1.x POMs return 404). NeoForge coverage starts at 26.1.2.
- **NeoForge 1.20.1:** the legacy 47.1.x line is covered by a binary-compatible Forge 1.20.1 jar copy and a live vanilla-client loot test.
- **Forge/Fabric parity:** every Minecraft version supported by Fabric is also covered by Forge except 26.4. Every published NeoForge version in the 1.20.1, 1.21.x and 26.1.2+ lines is covered.

## Client verification summary

- Full visual GUI tests: Fabric 26.3 / 1.21.1 / 1.20.1, Forge 26.3 / 1.20.1, NeoForge 26.3 / 1.21.1.
- Vanilla-client fallback (hologram + hitbox quick loot): Forge 1.21, 1.21.1, 26.3 and NeoForge 1.20.1.
- Remaining 26.x Forge/NeoForge/Fabric builds: dedicated-server boot + grave creation only (no visual GUI pass). The shared screen/renderer code is byte-identical to the visually tested 26.3/1.21.1 builds apart from version-specific API names.
- The 26.x GUI title now truncates with `...` when the grave owner name is long, keeping the despawn timer readable; this fix was rolled into all six Fabric 26.x jars on 2026-11-01.

## Publication status

- Modrinth: `publish-manifest.json` now has all **23 rows** and `publish-modrinth.mjs` validates against live tags. A dry run and a full mock upload (project creation, 23 uploads, duplicate skipping) pass. Real upload still requires the owner's Modrinth token; none is stored here.
- Website: `corpsegraves-site/dist` contains the Arabic download page with 23 rows, 30 jars (23 mods + 7 Fabric API), install guide and SHA-256 list. A temporary public Cloudflare tunnel is live (see `PUBLIC-SITE.md`); permanent Qoder Sites hosting is still blocked by `provider_unavailable`.
- CurseForge: same 22 files; upload needs the owner's CurseForge token and project ID.

## Install rules

- One mod jar per game/loader, matching exactly. Do not mix Fabric, Forge and NeoForge jars.
- Fabric: put the matching Fabric API jar in `mods` too. Forge/NeoForge need no extra dependency.
- Install on the server, and on clients for the corpse body and GUI.
- Delete older Corpse Graves jars before adding a new one.
- Config: `config/corpsegraves.json` (sample included); apply with `/corpsegraves reload`.
