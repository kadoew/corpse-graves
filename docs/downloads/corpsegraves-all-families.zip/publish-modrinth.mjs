import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const API = process.env.MODRINTH_API || 'https://api.modrinth.com/v2';
const args = process.argv.slice(2);
const publish = args.includes('--publish');
const skipTags = args.includes('--skip-tag-check');
const manifestArg = args.find(a => a.startsWith('--manifest='));
const projectIdArg = args.find(a => a.startsWith('--project-id='));
const manifestPath = manifestArg ? path.resolve(manifestArg.slice('--manifest='.length)) : path.join(here, 'publish-manifest.json');

function fail(message) {
	console.error('ERROR ' + message);
	process.exit(1);
}

function hashFile(file, algorithm) {
	return new Promise((resolve, reject) => {
		const hash = crypto.createHash(algorithm);
		createReadStream(file)
			.on('data', chunk => hash.update(chunk))
			.on('end', () => resolve(hash.digest('hex')))
			.on('error', reject);
	});
}

async function fetchJson(url, options) {
	const response = await fetch(url, options);
	const text = await response.text();
	let data = null;
	try { data = text ? JSON.parse(text) : null; } catch { data = text; }
	return { response, data };
}

const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
const project = manifest.project ?? fail('project is missing');
for (const field of ['slug', 'title', 'description', 'body', 'categories', 'project_type', 'license_id', 'environment']) {
	if (!project[field] || (Array.isArray(project[field]) && project[field].length === 0)) fail(`project.${field} is missing`);
}
if (project.description.length > 256) fail('project.description exceeds 256 characters');
const ENVIRONMENTS = new Set(['client_and_server', 'client_only', 'client_only_server_optional', 'singleplayer_only', 'server_only', 'server_only_client_optional', 'dedicated_server_only', 'client_or_server', 'client_or_server_prefers_both']);
if (!Array.isArray(project.environment) || project.environment.length !== 1 || !ENVIRONMENTS.has(project.environment[0])) {
	fail(`project.environment must contain one of: ${[...ENVIRONMENTS].join(', ')}`);
}
if (!Array.isArray(manifest.versions) || manifest.versions.length === 0) fail('versions are missing');

const dependencyMap = new Map((manifest.dependencies ?? []).map(d => [d.key, d]));
const seenNumbers = new Set();
const versions = [];
let totalBytes = 0;

for (const version of manifest.versions) {
	for (const field of ['name', 'version_number', 'file', 'game_versions', 'loaders', 'release_channel']) {
		if (!version[field] || (Array.isArray(version[field]) && version[field].length === 0)) fail(`${version.version_number ?? '?'}: ${field} is missing`);
	}
	if (seenNumbers.has(version.version_number)) fail(`duplicate version_number ${version.version_number}`);
	seenNumbers.add(version.version_number);
	const filePath = path.resolve(here, version.file);
	if (!filePath.startsWith(here + path.sep)) fail(`${version.version_number}: file escapes the release directory`);
	let stat;
	try { stat = await fs.stat(filePath); } catch { fail(`${version.version_number}: missing file ${version.file}`); }
	if (!stat.isFile() || stat.size === 0) fail(`${version.version_number}: invalid file ${version.file}`);
	if (!['release', 'beta', 'alpha'].includes(version.release_channel)) fail(`${version.version_number}: invalid release_channel`);
	const deps = (version.dependencies ?? []).map(key => {
		const dep = dependencyMap.get(key);
		if (!dep) fail(`${version.version_number}: unknown dependency key ${key}`);
		if (!dep.project_id) fail(`dependency ${key}: project_id is missing`);
		return { project_id: dep.project_id, dependency_type: dep.dependency_type ?? 'required' };
	});
	versions.push({
		...version,
		filePath,
		fileName: path.basename(filePath),
		size: stat.size,
		deps,
	});
	totalBytes += stat.size;
}

if (!skipTags) {
	try {
		const [gameTags, loaderTags, licenseTags] = await Promise.all([
			fetchJson(`${API}/tag/game_version`).then(r => r.data),
			fetchJson(`${API}/tag/loader`).then(r => r.data),
			fetchJson(`${API}/tag/license`).then(r => r.data),
		]);
		const gameSet = new Set(gameTags.map(t => t.version));
		const loaderSet = new Set(loaderTags.map(t => t.name));
		for (const version of versions) {
			for (const gameVersion of version.game_versions) {
				if (!gameSet.has(gameVersion)) fail(`${version.version_number}: Modrinth has no game tag "${gameVersion}"`);
			}
			for (const loader of version.loaders) {
				if (!loaderSet.has(loader)) fail(`${version.version_number}: Modrinth has no loader "${loader}"`);
			}
		}
		const license = licenseTags.find(l => String(l.short).toLowerCase() === project.license_id.toLowerCase());
		if (!license) fail(`Modrinth has no license id "${project.license_id}"`);
		project.license_id = license.short;
		console.log(`Tags OK: ${versions.length} versions, license=${license.short}`);
	} catch (error) {
		if (publish) fail(`tag validation failed: ${error.message}`);
		console.warn(`WARN tag validation skipped: ${error.message}`);
	}
}

for (const version of versions) {
	version.sha512 = await hashFile(version.filePath, 'sha512');
	version.sha1 = await hashFile(version.filePath, 'sha1');
}

console.log(`Manifest: ${manifestPath}`);
console.log(`Project: ${project.title} (${project.slug}) -> ${API}/project/${project.slug}`);
console.log(`Versions: ${versions.length}; total ${(totalBytes / 1024 / 1024).toFixed(2)} MiB`);
for (const version of versions) {
	console.log(`- ${version.version_number} [${version.loaders.join('+')}] ${version.game_versions.join(',')} ${version.release_channel} ${version.fileName} ${(version.size / 1024).toFixed(1)} KiB sha512=${version.sha512.slice(0, 16)}…`);
}

if (!publish) {
	console.log('DRY RUN OK. Set MODRINTH_TOKEN and rerun with --publish to upload.');
	process.exit(0);
}

const token = process.env.MODRINTH_TOKEN;
if (!token) fail('MODRINTH_TOKEN is not set');

let projectId = projectIdArg?.slice('--project-id='.length) || process.env.MODRINTH_PROJECT_ID || null;
if (!projectId) {
	const lookup = await fetchJson(`${API}/project/${encodeURIComponent(project.slug)}`);
	if (lookup.response.ok && lookup.data?.id) {
		projectId = lookup.data.id;
		console.log(`Using existing project ${projectId}`);
	} else if (lookup.response.status === 404) {
		const created = await fetchJson(`${API}/project`, {
			method: 'POST',
			headers: { Authorization: token, 'Content-Type': 'application/json' },
			body: JSON.stringify({
				slug: project.slug,
				title: project.title,
				description: project.description,
				body: project.body,
				categories: project.categories,
				project_type: project.project_type,
				license_id: project.license_id,
				environment: project.environment,
			}),
		});
		if (!created.response.ok) fail(`project creation failed ${created.response.status}: ${JSON.stringify(created.data)}`);
		projectId = created.data.id;
		console.log(`Created project ${projectId}: https://modrinth.com/mod/${created.data.slug}`);
	} else {
		fail(`project lookup failed ${lookup.response.status}: ${JSON.stringify(lookup.data)}`);
	}
}

const existing = await fetchJson(`${API}/project/${projectId}/version`, { headers: { Authorization: token } });
if (!existing.response.ok) fail(`cannot list existing versions ${existing.response.status}: ${JSON.stringify(existing.data)}`);
const existingNumbers = new Set((Array.isArray(existing.data) ? existing.data : []).map(v => v.version_number));
console.log(`Existing versions on project: ${[...existingNumbers].join(', ') || 'none'}`);

for (const version of versions) {
	if (existingNumbers.has(version.version_number)) {
		console.log(`SKIP ${version.version_number} (already uploaded)`);
		continue;
	}
	const data = {
		name: version.name,
		version_number: version.version_number,
		changelog: version.changelog
			? `${manifest.default_changelog ?? ''}\n\n${version.changelog}`.trim()
			: manifest.default_changelog,
		dependencies: version.deps,
		game_versions: version.game_versions,
		version_type: version.release_channel,
		loaders: version.loaders,
		featured: false,
		status: 'listed',
		project_id: projectId,
		file_parts: ['file'],
		primary_file: 'file',
		environment: version.environment ?? project.environment[0],
	};
	const form = new FormData();
	form.append('data', JSON.stringify(data));
	form.append('file', new Blob([await fs.readFile(version.filePath)], { type: 'application/java-archive' }), version.fileName);
	const uploaded = await fetchJson(`${API}/version`, {
		method: 'POST',
		headers: { Authorization: token },
		body: form,
	});
	if (!uploaded.response.ok) fail(`${version.version_number} upload failed ${uploaded.response.status}: ${JSON.stringify(uploaded.data)}`);
	console.log(`UPLOADED ${version.version_number}: https://modrinth.com/mod/${project.slug}/version/${uploaded.data.version_number}`);
	existingNumbers.add(version.version_number);
	await new Promise(resolve => setTimeout(resolve, 500));
}

console.log(`DONE. Project: https://modrinth.com/mod/${project.slug}`);
