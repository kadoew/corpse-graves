# Corpse Graves 1.1.0 — publication pack

Everything is built and tested; this file is the listing/upload sheet for Modrinth / CurseForge. Upload needs the project owner's account (Modrinth API token or CurseForge token); none is stored in this workspace.

## One-command Modrinth upload

`publish-manifest.json` encodes all **23 version rows** — 9 Fabric, 8 Forge, 6 NeoForge — validated against live Modrinth game/loader tags (including `26.4-snapshot-6` for the Fabric 26.4 jar). `publish-modrinth.mjs` checks every file and computes hashes, creates the project if the slug is free, skips versions already uploaded, and uploads the rest.

```bash
cd release
node publish-modrinth.mjs                 # dry run: files, hashes, tags
MODRINTH_TOKEN=... node publish-modrinth.mjs --publish
```

PowerShell:

```powershell
cd release
node publish-modrinth.mjs
$env:MODRINTH_TOKEN = "..."
node publish-modrinth.mjs --publish
```

The token needs project-create and version-create scopes. It is read from the environment only and is never written to disk. Optional: `--project-id=<id>` or `MODRINTH_PROJECT_ID` to target an existing project; otherwise the script reuses `corpse-graves` if it exists.

## Qoder Sites fallback

The Qoder Sites upload provider returned `sites_upload_unavailable` on 2026-10-31. A project/site now exists for recovery: project `01a1939d-0350-7919-af83-d6ba0f18ad1c`, site `01a1939d-0351-70ea-ab59-ed2a9674f252`, host `corpse-graves-cuubmwn7cm1.qoder.website` (private, no published content). The complete 22-row, 29-jar site (with the 18 MB all-families bundle) was prepared again on 2026-11-01; the upload verification ended terminal `provider_unavailable` after five retries, so nothing is published. When the provider recovers, prepare `corpsegraves-site/dist` against that project ID, publish, then set public access.

A temporary public mirror is live at https://cells-winners-governance-whatever.trycloudflare.com (Cloudflare quick tunnel to the local site; index, jar and the 18 MB bundle verified). It is not permanent and the URL changes after a restart; see `PUBLIC-SITE.md`.

## Project

- Name: **Corpse Graves**
- Slug: `corpse-graves`
- Mod id: `corpsegraves`
- License: MIT
- Categories: **Gameplay / Utility / Storage** (or "Adventure and RPG")
- Client side: required for the corpse model + GUI; optional for the server fallback
- Server side: required
- Summary (EN): *Never lose your loot again. A protected, skin-accurate corpse grave stores your items and XP and shows name, despawn and protection timers on a floating hologram.*
- Summary (AR): *لا تفقد غنائمك مرة أخرى. قبر محمي يعرض سكين اللاعب ويحفظ الأغراض والخبرة، مع هولوغرام يعرض الاسم ومؤقت الاختفاء والحماية.*

## Long description

### EN
Corpse Graves replaces dropped loot with a protected corpse grave. The fallen player's whole inventory and a configurable share of XP are stored in a grave body rendered with the player's real skin. A floating hologram shows the player name, the despawn countdown, and the protection countdown/status. Owners always have access; other players can loot after the configurable unlock timer (or never, if set to -1). Right-click opens a clean custom GUI with **Take All** and **Restore**, while **Shift + right-click** restores everything to its original slots instantly. The grave waits for the loot to be handled, survives restarts, can rescue loot lost in the void, and is deeply configurable through `config/corpsegraves.json` with `/corpsegraves reload`.

- Player-skin corpse body (live skin on the client; default profile skin when no skin is available)
- Owner protection + unlock timer + operator bypass
- Floating hologram: name, Despawns, Protected/Unlocked, configurable colors/scale/background
- Custom GUI (Take All / Restore) + Shift+right-click quick restore
- 50% XP recovery by default (0–100 configurable)
- Smart despawn, owner-offline pause, chunk-unload pause, restart persistence
- Void rescue, curse-of-vanishing support, max graves per player, coordinate announcement
- Fabric/Forge: vanilla clients can join and quick-loot via the server fallback (corpse body/GUI need the mod). NeoForge rejects vanilla clients, so a NeoForge client is required

### AR
قبر محمي يحفظ أغراض اللاعب وخبرته بدل إسقاطها. الجسد يعرض سكين اللاعب الحقيقي، والهولوغرام يعرض الاسم ومؤقت الاختفاء ومؤقت/حالة الحماية. صاحب القبر يستطيع فتحه دائماً، والآخرون بعد انتهاء مؤقت الحماية (أو للأبد إذا كان -1). الزر الأيمن يفتح واجهة فيها **Take All** و**Restore**، و**Shift + الزر الأيمن** يستعيد كل شيء لخاناته الأصلية فوراً. القبر ينتظر حتى تُفرَّغ الأغراض، ويبقى بعد إعادة تشغيل السيرفر، وينقذ الغنائم الساقطة في الفراغ، وكل شيء قابل للتعديل عبر `config/corpsegraves.json` ثم `/corpsegraves reload`.

## Version matrix (one file per row)

| Version name | File | Game versions | Loader | Java |
|---|---|---|---|---|
| `1.1.0+26.1` | `26.x/corpsegraves-1.1.0+26.1.jar` | 26.1 | Fabric (Loader 0.19+) | 25 |
| `1.1.0+26.1.1` | `26.x/corpsegraves-1.1.0+26.1.1.jar` | 26.1.1 | Fabric | 25 |
| `1.1.0+26.1.2` | `26.x/corpsegraves-1.1.0+26.1.2.jar` | 26.1.2 | Fabric | 25 |
| `1.1.0+26.2` | `26.x/corpsegraves-1.1.0+26.2.jar` | 26.2 | Fabric | 25 |
| `1.1.0+26.3` | `26.x/corpsegraves-1.1.0+26.3.jar` | 26.3 | Fabric | 25 |
| `1.1.0+26.4` | `26.x/corpsegraves-1.1.0+26.4.jar` | 26.4-alpha.6 | Fabric | 25 |
| `1.1.0+1.21.1` (Fabric) | `fabric-legacy/corpsegraves-1.1.0+1.21.1.jar` | 1.21.1 | Fabric | 21 |
| `1.1.0+1.21` | `fabric-legacy/corpsegraves-1.1.0+1.21.jar` | 1.21 | Fabric | 21 |
| `1.1.0+1.20.1` (Fabric) | `fabric-legacy/corpsegraves-1.1.0+1.20.1.jar` | 1.20.1 | Fabric | 17 |
| `1.1.0+1.21.1-neoforge` | `neoforge/corpsegraves-1.1.0+1.21.1-neoforge.jar` | 1.21.1 | NeoForge 21.1.176+ | 21 |
| `1.1.0+1.21-neoforge` | `neoforge/corpsegraves-1.1.0+1.21-neoforge.jar` | 1.21 | NeoForge 21.0.167+ | 21 |
| `1.1.0+26.3-neoforge` | `neoforge/corpsegraves-1.1.0+26.3-neoforge.jar` | 26.3 | NeoForge 26.3.0.100+ | 25 |
| `1.1.0+26.2-neoforge` | `neoforge/corpsegraves-1.1.0+26.2-neoforge.jar` | 26.2 | NeoForge 26.2.0.93+ | 25 |
| `1.1.0+26.1.2-neoforge` | `neoforge/corpsegraves-1.1.0+26.1.2-neoforge.jar` | 26.1.2 | NeoForge 26.1.2.125+ | 25 |
| `1.1.0+1.20.1-neoforge` | `neoforge/corpsegraves-1.1.0+1.20.1-neoforge.jar` | 1.20.1 | NeoForge 47.1.106+ (legacy Forge fork) | 17 |
| `1.1.0+1.20.1-forge` | `forge/corpsegraves-1.1.0+1.20.1-forge.jar` | 1.20.1 | Forge 47.x | 17 |
| `1.1.0+1.21-forge` | `forge/corpsegraves-1.1.0+1.21-forge.jar` | 1.21 | Forge 51.0.33+ | 21 |
| `1.1.0+1.21.1-forge` | `forge/corpsegraves-1.1.0+1.21.1-forge.jar` | 1.21.1 | Forge 52.1.20+ | 21 |
| `1.1.0+26.1-forge` | `forge/corpsegraves-1.1.0+26.1-forge.jar` | 26.1 | Forge 62.0.9+ | 25 |
| `1.1.0+26.1.1-forge` | `forge/corpsegraves-1.1.0+26.1.1-forge.jar` | 26.1.1 | Forge 63.0.2+ | 25 |
| `1.1.0+26.1.2-forge` | `forge/corpsegraves-1.1.0+26.1.2-forge.jar` | 26.1.2 | Forge 64.1.5+ | 25 |
| `1.1.0+26.2-forge` | `forge/corpsegraves-1.1.0+26.2-forge.jar` | 26.2 | Forge 65.1.5+ | 25 |
| `1.1.0+26.3-forge` | `forge/corpsegraves-1.1.0+26.3-forge.jar` | 26.3 | Forge 66.1.2+ | 25 |

Fabric dependencies: Fabric API 0.165.0+26.3 (26.3), 0.165.1+26.4 (26.4), 0.161.0+26.2 (26.2), 0.155.3+26.1.2 (26.1.x), 0.116.17+1.21.1, 0.102.0+1.21, 0.92.12+1.20.1. Fabric API jars are in `release/26.x` and `release/fabric-legacy`. NeoForge/Forge need no extra dependency.

## Upload steps (Modrinth)

1. Create the project `corpsegraves` with the summary/description above, MIT, and the Corpse Graves icon (`26.x`/`forge` assets include the icon in the jar; use `corpsegraves/icon.png` from the source assets).
2. For each row, create a version with the exact version name, upload the jar, set the game version(s) and loader, and add the corresponding Fabric API dependency (Fabric only).
3. Changelog: first release 1.1.0; list the features above plus the multi-loader matrix.
4. For CurseForge, mirror the same rows; the file names are already loader/version-specific.

## Verification status

- 26.3: full gameplay and client test (death, skin, hologram, GUI, 50% XP, restore, restart persistence, buttons). The exact release jar also booted dedicated servers on Fabric Loader 0.19.5 and 0.20.1 with Fabric API 0.165.0+26.3 (both `Done`).
- Forge 1.20.1: production dedicated server + real client test (death, grave, hologram/hitbox, Take All, Shift quick-restore, commands, restart persistence, custom GUI, live skin resolution). Two-player protection test: a non-owner was locked out with an empty inventory, then received all three stacks after `/corpsegraves unlock` and the grave was removed.
- Fabric 1.20.1: real dev-client pass on a Fabric dev server (corpse/hologram, custom GUI, Take All moved all stacks + 698 XP, grave removed). It also caught and fixed the Fabric legacy menu registration (`GraveMenu.TYPE` is now the registered `MenuType`); the 1.21/1.21.1 jars were rebuilt with the same fix.
- Fabric 1.21.1 client join: caught and fixed a payload-codec bug (`StreamCodec.unit(new HelloC2S())` rejected the client's packet instance and disconnected every modded join). The payload now uses `HelloC2S.INSTANCE` in 1.21/1.21.1; the 1.21.1 dev client connected successfully after the fix and the grave GUI opened. That screenshot exposed a visible hitbox debug name; the legacy hitbox name was removed and clicked-hitbox resolution now matches the corpse's saved `hitboxId`. Verified on 1.21.1 with a vanilla bot (click moved all five stacks + XP and removed the grave); all legacy/Forge jars rebuilt.
- Fabric 1.21: build green, dedicated server reaches `Done`, and it shares the tested legacy renderer/screen code (Fabric 1.20.1 and 1.21.1 client passes).
- NeoForge 1.21.1: full client pass on a dedicated server (skin corpse, hologram + both timers, GUI, Take All moved 5 stacks + 698 XP, grave removed). Caught and fixed a NeoForge-only `HelloC2S` unit-codec handshake bug; verified again with `Client handshake from Dev` in the server log.
- Forge 26.3: real Forge 66.1.2 client + production server — grave/hologram, GUI, Take All moved 3 stacks + 698 XP and removed the grave. NeoForge 26.3: identical real-client pass on 26.3.0.100.
- Forge 1.21.1 and 1.21: production servers with vanilla clients — grave creation, hologram, hitbox and quick loot took every item plus 698 XP. Two-player owner protection was verified on Forge 1.20.1.
- Forge 26.1, 26.1.1, 26.1.2 and 26.2, and NeoForge 1.21, 26.1.2 and 26.2: dedicated servers reached `Done` and created graves; no visual GUI pass yet.
- NeoForge 1.20.1 (47.1.106): binary-compatible Forge jar loaded; a vanilla client triggered the grave, clicked the Interaction hitbox, recovered 3 stacks + 698 XP and the grave/hologram/hitbox were removed.
- All 23 jars exist in `release/` with a matching `SHA256SUMS.txt`; the website bundle mirrors them. Fabric 26.x GUI title truncation was applied to all six Fabric 26.x builds on 2026-11-01.
