# Corpse Graves 1.1.0 — كل النسخ (Fabric 26.x + Fabric legacy + NeoForge + Forge)

**لا تفقد غنائمك مرة أخرى.** عند موت اللاعب تُحفظ كل أغراضه وخبرته داخل قبر محمي، مع جسد يعرض سكين اللاعب، وهولوغرام عائم يعرض الاسم والوقت المتبقي وحالة الحماية.

## النسخ المرفقة

| المنصة | Minecraft | الملف | المجلد |
|---|---|---|---|
| Fabric | 26.1، 26.1.1، 26.1.2، 26.2، 26.3، 26.4-alpha.6 | `corpsegraves-1.1.0+<version>.jar` | `26.x/` |
| Fabric | 1.20.1 / 1.21 / 1.21.1 | `corpsegraves-1.1.0+<version>.jar` | `fabric-legacy/` |
| Forge | 1.20.1 / 1.21 / 1.21.1 / 26.1 / 26.1.1 / 26.1.2 / 26.2 / 26.3 | `corpsegraves-1.1.0+<version>-forge.jar` | `forge/` |
| NeoForge | 1.20.1 / 1.21 / 1.21.1 / 26.1.2 / 26.2 / 26.3 | `corpsegraves-1.1.0+<version>-neoforge.jar` | `neoforge/` |

**المجموع: 23 جرّة — 9 Fabric + 8 Forge + 6 NeoForge.** لا توجد نسخة Forge/NeoForge لماين كرافت 26.4، ولا نسخ NeoForge منشورة لـ26.1/26.1.1. وكل نسخة Fabric لها مقابل Forge (عدا 26.4)، ونسخة NeoForge 1.20.1 هي توافق ثنائي مع جرة Forge وجُرِّبت بعميل Vanilla.

- تفاصيل كل منصة وطريقة تثبيتها: `README-MATRIX.md` ومجلدات `26.x/` و`fabric-legacy/` و`neoforge/` و`forge/`.
- حزمة واحدة بكل العائلات: `corpsegraves-all-families.zip`.
- **هذا القسم التالي يشرح نسخة 26.3 بالتفصيل** (وهي النسخة الأساسية التي جُرِّبت لعباً كاملاً على عميل حقيقي). بقية النسخ تستخدم نفس الميزات والإعدادات، مع فارق طريقة عرض الجسد على النسخ الأقدم.

---

## Corpse Graves — Minecraft 26.3 (Fabric)

> Built for **Minecraft 26.3**, **Fabric Loader 0.19.3+** and **Fabric API 0.165.0+26.3**.
> Java **25** is required by Minecraft 26.3.

---

## ⚡ التثبيت السريع (عربي)

1. ثبّت **Fabric Loader 0.19.3 أو أحدث** (يفضل 0.20.1). لا تستخدم نسخة أقدم من 0.19.3.
2. ضع هذه الملفات في مجلد `mods`:
   - `corpsegraves-1.1.0.jar` (هذا المود)
   - `fabric-api-0.165.0+26.3.jar` ← **مطلوب**، المود لن يعمل بدونه
   - `fabric-api` لا يأتي داخل المود؛ يجب تنزيله من Modrinth/CurseForge واختيار إصدار **26.3**.
3. تأكد أن **Java 25** هي المستخدمة (Minecraft 26.3 يتطلبها).
4. للتشغيل على سيرفر: ضع نفس الملفين في `mods` على السيرفر. اللاعبون بدون المود يستطيعون رؤية القبر والهولوغرام (لأنهما كيانات فانيلا)، وبالنقر يأخذون كل الأغراض مباشرة. أما الواجهة الرسومية (GUI) فتتطلب تثبيت المود عند اللاعب أيضاً.
5. الإعدادات تُنشأ تلقائياً في:
   - سيرفر: `config/corpsegraves.json`
   - لاعب: `config/corpsegraves.json`
   بعد تعديلها استخدم `/corpsegraves reload`.

> **الخطأ الشائع:** `requires version 0.20.0 or later of fabricloader` — تم إصلاحه في هذه النسخة؛ الحد الأدنى الآن **0.19.0** (وFabric API يحتاج 0.19.3 على الأقل).
> **الخطأ الشائع:** `fabric-api is missing` — نزّل Fabric API لإصدار 26.3 وضعه في `mods`.

---

## ✨ المميزات

- **جسد اللاعب الحقيقي**: كيان Mannequin من الفانيلا يعرض سكين اللاعب وإحداثيات الأغراض (درع/أوفهاند) بوضعية استلقاء.
- **حماية ذكية للمالك**: القبر مفتوح دائماً لصاحبه. الآخرون لا يستطيعون فتحه قبل انتهاء مؤقت الفتح (`unlockSeconds`)، و`-1` يعني حماية دائمة. المشرفون يمكنهم تجاوز الحماية (قابل للإيقاف).
- **هولوغرام عائم**: الاسم (ذهبي)، `Despawns: MM:SS` (فيروزي)، و`Protected: MM:SS` أو `Unlocked` (أحمر/أخضر)، بألوان وشعار وحجم قابلين للتعديل. يُحدَّث كل ثانية.
- **واجهة GUI**: انقر بالزر الأيمن لفتح واجهة مخصصة، وأخذ ما تريد. زر **Take All** وزر **Restore** (استعادة الأغراض لخاناتها الأصلية).
- **Shift + Right-Click**: استعادة فورية لكل الأغراض إلى خاناتها الأصلية، وما لا يتسع يبقى في القبر.
- **نظام اختفاء ذكي**: القبر يختفي فوراً عند فراغه، أو بعد المؤقت (افتراضياً 3600 ثانية). يمكن إيقاف المؤقت أثناء غياب صاحب القبر وعند إغلاق التشك (Chunk) حتى لا تضيع الفرصة.
- **استعادة الخبرة**: نسبة قابلة للتعديل (افتراضياً 50%)؛ تُمنح عند إفراغ القبر.
- **إنقاذ الفراغ (Void)**: إذا مات اللاعب في الفراغ، يبحث المود عن سطح آمن قريب ويضع القبر هناك (قابل للإيقاف).
- **توافق سيرفرات**: لا يستخدم أي حزم مخصصة للفانيلا. تم اختباره على سيرفر مخصص، ويحفظ القبور في بيانات العالم (`world/data/corpsegraves_graves.dat`) فلا تضيع بعد إعادة التشغيل.
- **يتعامل باحترام مع `keepInventory`**: إذا كان true لا يُنشأ قبر ولا تُمَس الأغراض.

## 🕹️ الأوامر

| الأمر | الوصف |
|---|---|
| `/corpsegraves list` | قائمة قبورك |
| `/corpsegraves locate` | إحداثيات أقرب قبر لك |
| `/corpsegraves reload` | إعادة تحميل الإعدادات (مشرف) |
| `/corpsegraves unlock <player>` | فتح كل قبور لاعب (مشرف) |
| `/corpsegraves remove <player>` | حذف قبور لاعب وإسقاط أغراضه (مشرف) |
| `/corpsegraves open <player>` | فتح أقرب قبر للاعب (مشرف/دعم) |
| `/corpsegraves restore <player>` | استعادة أقرب قبر للاعب (مشرف/دعم) |

---

## 🔧 Configuration (`config/corpsegraves.json`)

| Key | Default | Meaning |
|---|---|---|
| `enabled` | true | Master switch |
| `despawnSeconds` | 3600 | Grave lifetime; `-1` = never |
| `unlockSeconds` | 1800 | Protection countdown for other players; `0` = public, `-1` = owner-only forever |
| `pauseDespawnWhileOwnerOffline` | true | Freeze despawn countdown while the owner is offline |
| `pauseDespawnInUnloadedChunks` | true | Freeze timers when the grave chunk is unloaded |
| `operatorsBypassProtection` | true | Ops (gamemaster) can loot protected graves |
| `ownedGravesAlwaysAccessible` | true | Owner can always open the grave |
| `storeXp` | true | Store experience in the grave |
| `xpRecoveryPercent` | 50.0 | Percentage of stored XP returned |
| `respectCurseOfVanishing` | true | Vanishing-curse items are not stored |
| `maxGravesPerPlayer` | 10 | Oldest grave is dropped when exceeded |
| `dropLootOnDespawn` | true | Drop loot when the timer expires instead of deleting it |
| `removeWhenEmpty` | true | Remove the grave as soon as it is empty |
| `vanillaClientQuickLoot` | true | Non-modded clients take all items on interaction |
| `announceCoordinates` | true | Tell the player where the grave is |
| `corpse.pose` | SLEEPING | `SLEEPING`, `SWIMMING`, `CROUCHING`, `FALL_FLYING`, `STANDING` |
| `corpse.displayArmor` / `displayOffhand` | false | Show death equipment on the corpse (off = skin fully visible) |
| `corpse.yOffset` / `forwardOffset` / `yawOffset` | 0 | Fine-tune body placement |
| `corpse.particles` / `particleIntervalTicks` | true / 40 | Soul particles |
| `corpse.hitboxWidth` / `hitboxHeight` / `hitboxForwardOffset` | 3.2 / 1.4 / 0.0 | Clickable area covering the lying body |
| `hologram.enabled` | true | Toggle hologram |
| `hologram.showName` / `showDespawn` / `showProtection` | true | Lines |
| `hologram.height` / `forwardOffset` / `scale` | 1.45 / 0 / 1.4 | Placement and size |
| `hologram.lineWidth` | 220 | Max text width |
| `hologram.background` | `#66000000` | ARGB background (semi-transparent) |
| `hologram.nameColor` | `#FFAA00` | Name color |
| `hologram.despawnColor` | `#55FFFF` | Despawn line color |
| `hologram.protectedColor` / `unlockedColor` | `#FF5555` / `#55FF55` | Protection colors |
| `hologram.shadow` / `seeThrough` / `viewRange` | true / false / 64 | Rendering details |
| `voidRescue.enabled` | true | Rescue graves lost in the void |
| `voidRescue.triggerBelowY` | -60 | Rescue threshold |
| `voidRescue.searchRadius` | 8 | Horizontal search radius |

---

## 🧱 Building / Updating for a newer Minecraft version

```bash
# Java 25 is required
./gradlew build
# jar -> build/libs/corpsegraves-1.1.0.jar
```

The entire toolchain is pinned in `gradle.properties`:

```properties
minecraft_version=26.3
loader_version=0.20.1        # compile-time only; runtime minimum is 0.19.0
loom_version=1.19-SNAPSHOT
fabric_api_version=0.165.0+26.3
```

To port to a future Fabric release:

1. Set `minecraft_version`, `loom_version` and `fabric_api_version` to the versions on <https://fabricmc.net/develop>.
2. Run `./gradlew build`. API renames are the only expected friction; the mod intentionally uses **vanilla entities** (`Mannequin`, `Display.TextDisplay`, `Interaction`), so there is no custom renderer or entity registration to port.
3. The only mixin is `LivingEntityDeathMixin` (`dropAllDeathLoot`); update its target if Mojang renames that method.
4. Test with `./gradlew runServer` and the client; see `TESTING.md`.

### Why it is server-friendly

- No client-only classes load on a dedicated server (split source sets).
- The corpse, hologram and hitbox are vanilla entity types, so they are saved/synced by vanilla and even visible to unmodded clients.
- Grave data is stored with `SavedData` in the overworld data storage, independent of entity/chunk lifetime.
- All timers pause safely when chunks unload, and error handling prevents a bad grave from breaking the server tick.

---

## 🎨 Skin, XP and protection notes

- **Player skin**: the corpse is a vanilla Mannequin. On online-mode servers the real profile textures are used. On offline-mode servers and launchers that inject skins locally, the new client mixin reuses the live player's skin and caches it, so the corpse shows the player's own skin instead of Steve. This only works on clients that have the mod installed; unmodded clients fall back to the profile/default skin.
- **XP**: only **50%** of the death XP is returned by default. Change `xpRecoveryPercent` (0–100) in the JSON.
- **Protection countdown**: the hologram always shows two timers — `Despawns: MM:SS` and `Protected: MM:SS`. Others can loot after the protection countdown (`unlockSeconds`, 30 minutes by default). Set `unlockSeconds` to `-1` for a permanent owner-only grave, or `0` to make it public immediately.
- Existing configs are migrated once: the first load after updating applies the 50% XP, hidden armor and slimmer hologram defaults. Delete `config/corpsegraves.json` to regenerate a fresh file.

## 🆕 Changes in 1.1.0

- **Take All / Restore are now real clickable widgets** and use a dedicated action packet; they no longer depend on container-button packets.
- **Protection countdown restored**: the hologram shows both the despawn timer and the protection unlock timer (owner always has access during the countdown).
- **Live player skin**: a client mixin reuses the online player skin (including launcher-injected offline skins) for the corpse.
- **50% XP** by default, hidden armor by default so the skin is visible, and a slimmer semi-transparent hologram.
- GUI uses seven equipment slots (armor, offhand, body, saddle) and shows the recoverable XP amount.

## English quick start

1. Install **Fabric Loader 0.19.3+** (0.20.1 recommended) and **Fabric API 0.165.0+26.3**.
2. Drop `corpsegraves-1.1.0.jar` and the Fabric API jar into `mods` (client and/or server).
3. Java 25 is required.
4. Die. Loot is stored in a protected corpse. Right-click to open the GUI, Shift+Right-click to restore everything, owner is always allowed.
5. Edit `config/corpsegraves.json` and `/corpsegraves reload`.

Server-only installs work: unmodded clients can see the grave (vanilla entities) and take everything with a single click. Install the mod on the client for the custom GUI.

### Notes / limitations

- Custom skins are resolved through vanilla's profile/skin cache. On **online-mode** servers the player's real skin is used. On **offline-mode** servers without skin properties the grave falls back to the default skin; that is a limitation of offline authentication, not of the mod.
- Graves are tied to their dimension and position. If an admin deletes the entity, the mod recreates it while the chunk is loaded; if the grave data itself is deleted, the grave is gone.
- This is an original implementation; it is not a fork of another mod.
