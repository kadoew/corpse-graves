# Corpse Graves — NeoForge 1.21.1

- Mod: `corpsegraves-1.1.0+1.21.1-neoforge.jar`
- Requires **NeoForge 21.1.176+** for Minecraft **1.21.1** and **Java 21**.
- Dedicated server boot tested: `Done` (mod loaded, registries/AT/events OK).
- Full client pass: a real NeoForge 1.21.1 client joined the dedicated server, a real death created a grave, the skin corpse and three-line hologram rendered, the custom GUI opened, and **Take All** returned 5 stacks + 698 XP and removed the grave. This pass fixed a NeoForge-only handshake bug (`HelloC2S` unit codec now uses `INSTANCE`); the server log confirms `Client handshake from Dev`.
- Client must have the mod for the custom corpse body/skin and the grave GUI. NeoForge rejects vanilla clients during network negotiation, so a NeoForge client (with or without this mod) is required; a NeoForge client without Corpse Graves gets the server-side quick-loot fallback.
- Config: `config/corpsegraves.json`; sample included. Reload with `/corpsegraves reload`.
- Migration from the Fabric versions is not done automatically; the JSON format is identical, copy your config file.
- The custom corpse renderer uses the live player skin; pose/offset verified on the NeoForge client (`corpse.yOffset` configurable).
- Classic Forge 1.20.1 is a separate port; NeoForge 21.1 is the Forge-family target for 1.21.1.
