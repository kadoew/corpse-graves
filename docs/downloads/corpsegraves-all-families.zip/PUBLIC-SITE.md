# Corpse Graves — الرابط العام الحالي (مؤقت)

**الرابط (2026-11-01 02:05):** https://cells-winners-governance-whatever.trycloudflare.com

يعرض هذا الرابط الموقع الكامل: 23 صف تحميل، 30 جرة (23 مود + 7 Fabric API)، والحزمة الكاملة 18 م.ب. تم التحقق من الصفحة والجرة والحزمة عبر الرابط العام (HTTP 200).

## الحالة

هذا **نفق Cloudflare Quick Tunnel** مؤقت يعرض `corpsegraves-site/dist` من هذا الجهاز. يبقى صالحاً ما دام:
- خادم المعاينة `node server.js` يعمل على المنفذ 4173،
- وعملية `cloudflared.exe` تعمل.

إذا توقفت العملية يتوقف الرابط، وعند إعادة التشغيل يتغيّر العنوان.

## إعادة التشغيل

```bat
cd /d "D:\mc modes\corpsegraves-site"
start "" node server.js

cd /d "D:\mc modes\tools"
cloudflared.exe tunnel --url http://localhost:4173 --no-autoupdate
```

انسخ عنوان `*.trycloudflare.com` الجديد من مخرجات cloudflared.

## لماذا ليس موقعاً دائماً بعد؟

- **Qoder Sites:** محاولة رفع الموقع الكامل اليوم انتهت بالخطأ `provider_unavailable` بعد خمس محاولات (المشروع/الموقع خاص بلا محتوى منشور). عند عودة المزوّد أعد التجهيز على المشروع `01a1939d-0350-7919-af83-d6ba0f18ad1c`.
- **Modrinth/CurseForge:** الرفع يحتاج توكن المالك. الحزمة جاهزة: 22 نسخة في `publish-manifest.json`، ومسار الرفع الكامل (إنشاء مشروع + 22 رفعاً + تخطي المكرر) جُرِّب بنجاح على خادم محلي وهمي.

```bash
cd release
MODRINTH_TOKEN=... node publish-modrinth.mjs --publish
```

لا تُعلن أي من هذه القنوات منشورة دائماً قبل نجاح الرفع الفعلي.
