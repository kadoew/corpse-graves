# Corpse Graves — 26.x family (Fabric)

Built and boot-tested in this order, without skipping releases.

| Minecraft | Mod jar | Fabric API (required) | Java | Loader | Tested |
|---|---|---|---|---|---|
| 26.1 | corpsegraves-1.1.0+26.1.jar | fabric-api-0.155.3+26.1.2.jar | 25 | 0.19.3+ | dedicated server boot: Done |
| 26.1.1 | corpsegraves-1.1.0+26.1.1.jar | fabric-api-0.155.3+26.1.2.jar | 25 | 0.19.3+ | built (same 26.1 source/API) |
| 26.1.2 | corpsegraves-1.1.0+26.1.2.jar | fabric-api-0.155.3+26.1.2.jar | 25 | 0.19.3+ | built (same 26.1 source/API) |
| 26.2 | corpsegraves-1.1.0+26.2.jar | fabric-api-0.161.0+26.2.jar | 25 | 0.19.3+ | dedicated server boot: Done |
| 26.3 | corpsegraves-1.1.0+26.3.jar | fabric-api-0.165.0+26.3.jar | 25 | 0.19.0+ | full client/server test (death, GUI, 50% XP, restore, skin, hologram, restart) |
| 26.4 (snapshot alpha.6) | corpsegraves-1.1.0+26.4.jar | fabric-api-0.165.1+26.4.jar | 25 | 0.19.3+ | dedicated server boot: Done |

## Install (each version separately)
1. Delete any older Corpse Graves jar from `mods` (do not keep two versions of the same mod).
2. Put **one** corpsegraves jar and the **matching** Fabric API jar into `mods`.
3. Java 25 is required for all 26.x releases.
4. Client and server can both use the same jar. The GUI is client-side; the server enforces protection/timers.
5. Config: `config/corpsegraves.json` (sample included); `/corpsegraves reload` after editing.
6. 26.4 is a snapshot (`26.4-alpha.6`), so its mod metadata accepts `>=26.4-alpha.6 <26.5`.

## Notes
- 26.x uses the vanilla Mannequin + TextDisplay architecture; no custom renderer is needed.
- 26.4 changed the GUI pipeline (`GuiPipeline`/`MenuScreens` registry); that port is included and compiles/boots.
- 26.1.x uses `EntityType` constants; 26.2+ uses `EntityTypes`; the version-specific source is already handled.
- The remaining targets are 1.21, 1.21.1, 1.20.1 and Forge/NeoForge in that order.
